import { EnquiryDetails } from './enquiry-details';

describe('EnquiryDetails', () => {
  it('should create an instance', () => {
    expect(new EnquiryDetails()).toBeTruthy();
  });
});
