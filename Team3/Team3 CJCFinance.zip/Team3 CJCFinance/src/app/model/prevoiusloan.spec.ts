import { Prevoiusloan } from './prevoiusloan';

describe('Prevoiusloan', () => {
  it('should create an instance', () => {
    expect(new Prevoiusloan()).toBeTruthy();
  });
});
