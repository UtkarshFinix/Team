export class AccountDetails
 {
    accountid:number;
	 accountype:string;
	accountHolderName:string ;
	accountStatus:string ;
	accountNO:string ;
	IFSC_Code:string ;
}
