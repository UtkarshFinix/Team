import { ProfInfo } from './prof-info';

describe('ProfInfo', () => {
  it('should create an instance', () => {
    expect(new ProfInfo()).toBeTruthy();
  });
});
