export class CustomerAddress 
{
    aId:number;
    houseno:string;
    streetname:string;
    areaname:string;
    cityname:string;
    pincode:string;
    district:string;
    state:string;
}
