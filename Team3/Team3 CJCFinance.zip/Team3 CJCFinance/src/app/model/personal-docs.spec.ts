import { PersonalDocs } from './personal-docs';

describe('PersonalDocs', () => {
  it('should create an instance', () => {
    expect(new PersonalDocs()).toBeTruthy();
  });
});
