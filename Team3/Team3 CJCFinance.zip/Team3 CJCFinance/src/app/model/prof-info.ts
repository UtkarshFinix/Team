export class ProfInfo 
{
    propertyid:number;
	propertytype:string ;
	propertyArea:string;
	constructionArea:string ;
	propertyPrice:string ;
	constructionPrice:string;
	property_Address:string;
}
