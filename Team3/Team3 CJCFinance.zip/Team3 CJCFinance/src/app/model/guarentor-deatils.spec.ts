import { GuarentorDeatils } from './guarentor-deatils';

describe('GuarentorDeatils', () => {
  it('should create an instance', () => {
    expect(new GuarentorDeatils()).toBeTruthy();
  });
});
