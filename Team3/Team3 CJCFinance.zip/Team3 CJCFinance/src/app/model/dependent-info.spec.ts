import { DependentInfo } from './dependent-info';

describe('DependentInfo', () => {
  it('should create an instance', () => {
    expect(new DependentInfo()).toBeTruthy();
  });
});
