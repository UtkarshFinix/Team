export class PersonalDocs
 {
     
	'did':any;
	'customerid':any;
	'addressproof':any;
	'pancard':any;
	'itr':any;
	'addharcard':any;
	'photo':any;
	'signature':any;
	'status':any;
}
