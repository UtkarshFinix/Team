export class EnquiryDetails 
{
    eid:number;
	name:string;
	dob:string;
	age:number;
	gender:string;
	email:string;
	mobileNo:string;
	pancardNo:string;
	adharno:string;
	cibil:number;
	status: string;
}
