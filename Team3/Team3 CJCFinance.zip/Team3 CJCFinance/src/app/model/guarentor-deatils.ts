export class GuarentorDeatils 
{
    gid:number;
	gName:string; 
	gDateofBirth:string;
	gRelationshipwithCustomer:string;
	gMobNo:string;
	gAdharCardNo:string;
	gJobDetails:string;
	gloaclAddress:string;
	gPermanentAddress:string;
	
}
