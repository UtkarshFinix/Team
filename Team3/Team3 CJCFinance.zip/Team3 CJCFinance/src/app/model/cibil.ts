export class Cibil 
{
    random_int:number;
    cibilScore:number;
}
