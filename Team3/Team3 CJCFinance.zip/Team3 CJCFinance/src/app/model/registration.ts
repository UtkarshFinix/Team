import { AccountDetails } from "./account-details";
import { CustomerAddress } from "./customer-address";
import { DependentInfo } from "./dependent-info";
import { GuarentorDeatils } from "./guarentor-deatils";
import { PersonalDocs } from "./personal-docs";
import { Prevoiusloan } from "./prevoiusloan";
import { ProfInfo } from "./prof-info";

export class Registration
 
{
    eID:number;
	Name:string;
	DOB:string;
	Age:number;
	Gender:string;
	Email:string;
    mobno:string;
	 cAdditionalMobileNo:string;
	 cTotalLoanRequired:string; 
	 Totalamount:string;
	 PayableDownpaymnt:string;
	 Tenure:number;
	 cibilscore:string;

//1.
pdocs:PersonalDocs ;
//2.
dinfo:DependentInfo ;
//3.
caddrs:CustomerAddress ;
//4.
ploan:Prevoiusloan ;
//5.
 adetails:AccountDetails;
//6.
pinfo:ProfInfo ;
//7.
gdetails:GuarentorDeatils ;
}
