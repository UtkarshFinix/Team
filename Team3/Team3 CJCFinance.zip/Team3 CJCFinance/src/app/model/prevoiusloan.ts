export class Prevoiusloan
 {
     ploanId:number;
	 ploanAmount:string;
	 pTenure:number;
	 paidAmount:string;
	 remainingAmount:string;
	 previousbankIFSC:string;
	 status:string;
	 remark:string;
}
