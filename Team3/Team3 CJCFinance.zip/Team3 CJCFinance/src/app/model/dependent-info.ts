export class DependentInfo 
{
    dId:number;
	 fatherName:string;
      motherName:string;
	 noOfFamilyMember:string;
	 noOfChild:string;
	 maritalStatus:string;
	 dependentMember:string;
	 familyIncome:string;
	 spouseName:string;
}
