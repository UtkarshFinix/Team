import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


import { Location } from '@angular/common';
import { EnqcommonService } from 'app/shared/enqcommon.service';
import { EnquiryDetails } from 'app/model/enquiry-details';



@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  constructor(private routes:ActivatedRoute, private common: EnqcommonService,private locations: Location) { }

  employeeObj! : EnquiryDetails;

  ngOnInit(): void {
     

  // // Second way is Observable
  this.routes.paramMap.subscribe(param1=>
    {
    let empId=parseInt(param1.get('eid')!);//added ! extra to resolve error
  console.log(empId);
   // let empId=parseInt(param1.get('id'));//error gone as strict :false in tsconfig.json
    //let empId=(param1.get('id'));
    this.common.getSingle(empId).subscribe
    (data=>
      {
        console.log(data);
      this.employeeObj=data;
      }
    )
  })
  }
 

  getback() {
    this.locations.back();

  }
 
}

