import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Registration } from 'app/model/registration';
import { RegcommonService } from 'app/shared/regcommon.service';
@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  

  constructor(private routes:ActivatedRoute,private common: RegcommonService, private locations: Location) { }

 
  customerObj: Registration;

  ngOnInit(): void {

    this.routes.paramMap.subscribe(param1=>
      {
      let cId=parseInt(param1.get('eID')!);
    console.log(cId);
      this.common.getSingle(cId).subscribe
      (data=>
        {
          console.log(data);
        this.customerObj=data;
        }
      )
    })
    }
  
    getback() {
      this.locations.back();
  
    }
   
}
