import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { ViewequiryComponent } from './viewequiry/viewequiry.component';
import { ViewcusstomerComponent } from './viewcusstomer/viewcusstomer.component';
import { CibilscoreComponent } from './cibilscore/cibilscore.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { ViewdocComponent } from './viewdoc/viewdoc.component';


const oerouting: Routes = [
  {path:'',component:DashboardComponent},

  {path: 'oedash', component: DashboardComponent},
  {path:'oeenq',component:ViewequiryComponent,
  children:
  [{path:'employeedetails/:eid',component:EmployeeDetailsComponent},
  {path:'custdetails/:eid',component:CustomerDetailsComponent},
 {path:'update',component:UpdateCustomerComponent},
 //{path:'update/did:',component:},

  ]
},
{path:'Sanction',component:ViewdocComponent},
  {path:'oecustomer',component:ViewcusstomerComponent},
  // {path:'cibil',component:CibilscoreComponent},
];
@NgModule({
  declarations: [DashboardComponent, ViewequiryComponent, ViewcusstomerComponent, CibilscoreComponent, CustomerDetailsComponent, ViewdocComponent],
  imports: [
    CommonModule,RouterModule.forChild(oerouting), ReactiveFormsModule,FormsModule
  ]
})
export class OperationexecutiveModule { }
