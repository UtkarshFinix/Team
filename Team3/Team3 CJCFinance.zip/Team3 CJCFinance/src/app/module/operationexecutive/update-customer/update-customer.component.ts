import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EnqcommonService } from 'app/shared/enqcommon.service';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
  constructor(private _fb:FormBuilder, private common:EnqcommonService, private locations:Location) { }

  updateForm!: FormGroup;

  ngOnInit(): void {
    this.updateForm = this._fb.group({
      eid:['',Validators.required],
      name:['',Validators.required],
      dob:['',Validators.required],
      age:['',Validators.required],
      gender:['',Validators.required],
      email:['',Validators.required],
      mobileNo:['',Validators.required],
      pancardNo:['',Validators.required],
      adharno:['',Validators.required],
      cibil:['',Validators.required],
      status:['',Validators.required]
    })
    this.editData();
    // this.getScore();
  }

  editData(){
    let cObj:any =this.locations.getState();
    console.log("getState() "+cObj.eid);
    console.log("getState() "+cObj.name);
    if(cObj.eid!=0)
    {
     //added ? extra for error resolving
      this.updateForm.get('eid').setValue(cObj.eid);
      this.updateForm.get('name')?.setValue(cObj.name);
      this.updateForm.get('dob')?.setValue(cObj.dob);
      this.updateForm.get('age')?.setValue(cObj.age);
      this.updateForm.get('gender')?.setValue(cObj.gender);
      this.updateForm.get('email')?.setValue(cObj.email);
      this.updateForm.get('mobileNo')?.setValue(cObj.mobileNo);
      this.updateForm.get('pancardNo')?.setValue(cObj.pancardNo);
      this.updateForm.get('adharno')?.setValue(cObj.adharno);
      this.updateForm.get('cibil')?.setValue(cObj.cibil);
      this.updateForm.get('status')?.setValue(cObj.status);
      console.log("updated");
     
    }
  }

  cibils:any;
  getScore()
  {
  this.common.getcibildata().subscribe((cb:any)=>{console.log(cb);
  this.cibils=cb;
   });
 }

  onSubmit(){
    this.common.updateCustomer(this.updateForm.value).subscribe();
  alert("Update Successfully");
  // window.location.reload(); 
  this.locations.back();
  }
  goBack() {
    this.locations.back();

  }
}
