import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Registration } from 'app/model/registration';
import { RegcommonService } from 'app/shared/regcommon.service';

@Component({
  selector: 'app-viewcusstomer',
  templateUrl: './viewcusstomer.component.html',
  styleUrls: ['./viewcusstomer.component.css']
})
export class ViewcusstomerComponent implements OnInit {

  registerForm!:FormGroup;  //added for registration thorugh emp-list

  constructor(private common: RegcommonService, private locations: Location) { }

  clist: Registration[];

  ngOnInit() {
    
    this.common.getRegdata().subscribe((data:Registration[])=>{this.clist=data;})
    // (list=>this.clist = list);
                                    
  }
  getback() {
    this.locations.back();
  }
 
  
  
}
