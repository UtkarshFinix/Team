import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Cibil } from 'app/model/cibil';
import { EnquiryDetails } from 'app/model/enquiry-details';
import { EnqcommonService } from 'app/shared/enqcommon.service';
import { RegcommonService } from 'app/shared/regcommon.service';

@Component({
  selector: 'app-viewequiry',
  templateUrl: './viewequiry.component.html',
  styleUrls: ['./viewequiry.component.css']
})
export class ViewequiryComponent implements OnInit {
  registerForm:FormGroup;  //added for registration thorugh emp-list

  constructor(private common: EnqcommonService, private locations: Location,private r:Router) { }

  elist!: EnquiryDetails[];
  random_int:Cibil;

  ngOnInit() {
    this.common.getdata().subscribe(list=>this.elist = list);   
                             
  }
  getback() {
    this.locations.back();
  }
}
