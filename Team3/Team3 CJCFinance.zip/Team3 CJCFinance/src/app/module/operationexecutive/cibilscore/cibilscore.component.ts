import { Component, OnInit } from '@angular/core';
import { EnqcommonService } from 'app/shared/enqcommon.service';

@Component({
  selector: 'app-cibilscore',
  templateUrl: './cibilscore.component.html',
  styleUrls: ['./cibilscore.component.css']
})
export class CibilscoreComponent implements OnInit {

  constructor(private common:EnqcommonService) { }

  ngOnInit(): void
  {
    
  }
 
}
