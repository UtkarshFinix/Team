import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { PersonalDocs } from 'app/model/personal-docs';
import { PdocscommonService } from 'app/shared/pdocscommon.service';

@Component({
  selector: 'app-viewdoc',
  templateUrl: './viewdoc.component.html',
  styleUrls: ['./viewdoc.component.css']
})
export class ViewdocComponent implements OnInit {

  constructor(private common: PdocscommonService, private locations: Location,private r:Router) { }

  verification: FormGroup;

  elist:PersonalDocs[];
  retrievedDoc:any;
  imageSrc:any;
  imageSrc1:any;
  imageSrc2:any;
  imageSrc3:any;
  imageSrc4:any;
  imageSrc5:any;
  imageSrc6:any;
  reader=new FileReader();
  ngOnInit(): void {
    this.common.getdata().subscribe((d:any[])=>{
      this.retrievedDoc = d;
     
    });
  }
  mail(){
    // this.common.mailsender().subscribe()
    alert("Sanction latter send");
  }
}
