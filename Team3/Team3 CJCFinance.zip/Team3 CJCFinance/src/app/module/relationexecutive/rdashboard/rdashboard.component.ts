import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rdashboard',
  templateUrl: './rdashboard.component.html',
  styleUrls: ['./rdashboard.component.css']
})
export class RdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
