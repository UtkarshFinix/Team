import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EnqcommonService } from 'app/shared/enqcommon.service';

@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent implements OnInit {

  enqForm!:FormGroup;
  
  constructor(private _fb:FormBuilder, private commonService: EnqcommonService, private location:Location) { }

  ngOnInit(): void {
    this.enqForm=this._fb.group(
      {
        
        name:['',Validators.required],
        dob:['',Validators.required],
        age:['',Validators.required],
        gender:['',Validators.required],
        email:['',Validators.required],
        mobileNo:['',Validators.required],
        pancardNo:['',Validators.required],
        adharno:['',Validators.required],
        cibil:['']
      }
    )
  }
  onSubmit()
  {
    alert("Enquired Successfully!")
    if(this.enqForm.valid)
    {
      console.log("in submit method");
      console.log(this.enqForm.value.name);
      console.log(this.enqForm.value.dob);
      console.log(this.enqForm.value.age);
      console.log(this.enqForm.value.gender);
      console.log(this.enqForm.value.email);
      console.log(this.enqForm.value.mobileNo);
      console.log(this.enqForm.value.pancardNo);
      console.log(this.enqForm.value.adharno);

      this.commonService.saveEnq(this.enqForm.value).subscribe();
      // this.commonService.getcibildata(this.enqForm.value).subscribe();
      
    }
    this. goBack();
  }

  goBack()
  {
      this.location.back();
  }
  reset()
  {
    this.enqForm.reset();
  }

  
}



