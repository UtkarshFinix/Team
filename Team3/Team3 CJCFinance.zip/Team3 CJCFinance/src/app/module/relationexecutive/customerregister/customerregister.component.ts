import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PdocscommonService } from 'app/shared/pdocscommon.service';
import { RegcommonService } from 'app/shared/regcommon.service';

@Component({
  selector: 'app-customerregister',
  templateUrl: './customerregister.component.html',
  styleUrls: ['./customerregister.component.css']
})
export class CustomerregisterComponent implements OnInit {

  RegForm:FormGroup;

  constructor(private _fb:FormBuilder, private commonService:RegcommonService , private location:Location,private cs: PdocscommonService) { }
  ngOnInit(): void {
    this.RegForm=this._fb.group(
      {
        // eID:['',Validators.required],
	      name:['',Validators.required],
	      dob:['',Validators.required],
	      age:['',Validators.required],
	      gender:['',Validators.required],
	      email:['',Validators.required],
	      mobno:['',Validators.required],
	      cAdditionalMobileNo:['',Validators.required],
	      cTotalLoanRequired:['',Validators.required],
	      totalamount:['',Validators.required],
	      payableDownpaymnt:['',Validators.required],
	      tenure:['',Validators.required],
	      cibilscore:['',Validators.required],

        dinfo:this._fb.group
        ({
          // dId:['',Validators.required],
	        fatherName:['',Validators.required],
          motherName:['',Validators.required],
	        noOfFamilyMember:['',Validators.required],
	        noOfChild:['',Validators.required],
	        maritalStatus:['',Validators.required],
	        dependentMember:['',Validators.required],
	        familyIncome:['',Validators.required],
	        spouseName:['',Validators.required]
        }),
        caddrs:this._fb.group
        ({
          
           // aId:['',Validators.required],
           houseno:['',Validators.required],
           streetname:['',Validators.required],
                areaname:['',Validators.required],
                cityname:['',Validators.required],
                district:['',Validators.required],
                pincode:['',Validators.required],
                state:['',Validators.required]
        }),
        ploan:this._fb.group
        ({
          // ploanId:['',Validators.required],
          ploanAmount:['',Validators.required],
          pTenure:['',Validators.required],
          paidAmount:['',Validators.required],
          remainingAmount:['',Validators.required],
          previousbankIFSC:['',Validators.required],
          status:['',Validators.required],
          remark:['',Validators.required]
        }),
        adetails:this._fb.group
        ({
          // accountid:['',Validators.required],
	        accountype:['',Validators.required],
	        accountHolderName:['',Validators.required],
	        accountStatus:['',Validators.required],
	        accountNO:['',Validators.required],
	        ifsc_Code:['',Validators.required]
        }),
        pinfo:this._fb.group
        ({
          // propertyid:['',Validators.required],
          propertytype:['',Validators.required],
          propertyArea:['',Validators.required],
          constructionArea:['',Validators.required],
          propertyPrice:['',Validators.required],
          constructionPrice:['',Validators.required],
          property_Address:['',Validators.required]
        }),
        gdetails:this._fb.group
        ({
          // gid:['',Validators.required],
	        gName:['',Validators.required],
	        gDateofBirth:['',Validators.required],
	        gRelationshipwithCustomer:['',Validators.required],
	        gMobNo:['',Validators.required],
	        gAdharCardNo:['',Validators.required],
	        gJobDetails:['',Validators.required],
	        gloaclAddress:['',Validators.required],
	        gPermanentAddress:['',Validators.required]
        })
      }
    )
  }

  onSubmit()
  {
      this.commonService.saveReg(this.RegForm.value).subscribe();
    console.log(this.RegForm.value.eID);
    console.log(this.RegForm.value.name);
    console.log(this.RegForm.value.tenure);
      this.commonService.saveDInfo(this.RegForm.value).subscribe();
      this.commonService.saveCAddress(this.RegForm.value).subscribe();
      this.commonService.savePloan(this.RegForm.value).subscribe();
      this.commonService.savead(this.RegForm.value).subscribe();
      this.commonService.savePI(this.RegForm.value).subscribe();
      this.commonService.saveGdata(this.RegForm.value).subscribe();
      this.commonService.saveLD(this.RegForm.value).subscribe();
      this.commonService.saveLedgerdata(this.RegForm.value).subscribe();
      this.commonService.saveSanctiondata(this.RegForm.value).subscribe();
   
      console.log("Registered successfully!"); 
      // this.goalrt();
      this.reset();
  }
 
  goalrt()
  {
     alert("Registered Successfully!");
      this.location.back();
  }

  goBack()
  {
    //  alert("Registered Successfully!");
      this.location.back();
  }
  reset()
  {
    alert("Registered Successfully!");
    this.RegForm.reset();
  }
  // next()
  // {
  //   this.location.forward();
  // }
  
}



