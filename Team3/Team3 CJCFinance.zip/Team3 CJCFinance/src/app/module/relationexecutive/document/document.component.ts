
import { Component, OnInit } from '@angular/core';

import { PdocscommonService } from 'app/shared/pdocscommon.service';

@Component({
  selector: 'app-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.css']
})
export class DocumentComponent implements OnInit {
  location: any;
  constructor(private cs: PdocscommonService ) { }

  doc=new Document();//to store document_id and customer_id(sending in string)
  customerid: any;
  selectaddressproof: any;
  selectpancard: any;
  selectitr: any;
  selectaddharcard: any;
  selectphoto:any;
  selectsignature:any;

  doclist= false;
  docform= true;

  //docform=FormBuilder;

  doc3: Document[];
  retrievedDoc:any;
  //retrievedDoc1:any;
  imageSrc:any;
  imageSrc1:any;
  imageSrc2:any;
  imageSrc3:any;
  imageSrc4:any;
  imageSrc5:any;
  reader=new FileReader();
  ngOnInit(): void {
  }

  onSelectedFile1(event: any){
    this.selectaddressproof = event.target.files[0];
    console.log(this.selectaddressproof);

    //to preview uploaded image
    const file = event.target.files[0];
    this.reader.onload = e => this.imageSrc = this.reader.result;
    this.reader.readAsDataURL(file);
  }
  onSelectedFile2(event: any){
    this.selectpancard = event.target.files[0];
    console.log(this.selectpancard);

    //to preview uploaded image
    const file = event.target.files[0];
    this.reader.onload = e => this.imageSrc1 = this.reader.result;
    this.reader.readAsDataURL(file);
  }
  onSelectedFile3(event: any){
    this.selectitr=event.target.files[0];
    console.log(this.selectitr);    

    //to preview uploaded image
    const file = event.target.files[0];
    this.reader.onload = e => this.imageSrc2 = this.reader.result;
    this.reader.readAsDataURL(file);
  }
  onSelectedFile4(event:any){
    this.selectaddharcard=event.target.files[0];
    console.log(this.selectaddharcard);

    //to preview uploaded image
    const file = event.target.files[0];
    this.reader.onload = e => this.imageSrc3 = this.reader.result;
    this.reader.readAsDataURL(file);
  }

  onSelectedFile5(event:any){
    this.selectphoto=event.target.files[0];
    console.log(this.selectphoto);

    //to preview uploaded image
    const file = event.target.files[0];
    this.reader.onload = e => this.imageSrc4 = this.reader.result;
    this.reader.readAsDataURL(file);
  }

  onSelectedFile6(event:any){
    this.selectsignature=event.target.files[0];
    console.log(this.selectsignature);

    //to preview uploaded image
    const file = event.target.files[0];
    this.reader.onload = e => this.imageSrc5 = this.reader.result;
    this.reader.readAsDataURL(file);
  }


  onRegister(){
    console.log('==in ts file==');
    console.log(this.doc);

    const document1=JSON.stringify(this.doc);
    const uploadDocument=new FormData();
    uploadDocument.append('addressproof',this.selectaddressproof);
    console.log(this.selectaddressproof);

    uploadDocument.append('pancard',this.selectpancard);
    uploadDocument.append('itr',this.selectitr);
    uploadDocument.append('addharcard',this.selectaddharcard);
    uploadDocument.append('photo',this.selectphoto);
    uploadDocument.append('signature',this.selectsignature);
    uploadDocument.append('doc',document1);
    console.log(this.doc);

    this.cs.saveDoc(uploadDocument).subscribe((data: any)=>{
      this.doc3=data;
      alert("Document Uploded..")
    });
  }


  goBack()
  {
      this.location.back();
  }
  next()
  {
    this.location.forward();
  }
  
}




    

