import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { EnquiryDetails } from 'app/model/enquiry-details';
import { EnqcommonService } from 'app/shared/enqcommon.service';


@Component({
  selector: 'app-viewequiry',
  templateUrl: './viewequiry.component.html',
  styleUrls: ['./viewequiry.component.css']
})
export class ViewequiryComponent implements OnInit {
  registerForm!:FormGroup;  //added for registration thorugh emp-list

  constructor(private common: EnqcommonService, private locations: Location,private r:Router) { }
  elist: EnquiryDetails[];
  ngOnInit() {   
    this.common.getdata().subscribe(list=>this.elist = list);                                 
  }
  mail(e:EnquiryDetails){
    this.common.mailsender(e).subscribe()
    alert("mail send")
  }
  getback() {
    this.locations.back();
  }
}
