import { TestBed } from '@angular/core/testing';

import { RegcommonService } from './regcommon.service';

describe('RegcommonService', () => {
  let service: RegcommonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RegcommonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
