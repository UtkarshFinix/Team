import { TestBed } from '@angular/core/testing';

import { PdocscommonService } from './pdocscommon.service';

describe('PdocscommonService', () => {
  let service: PdocscommonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PdocscommonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
