import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnquiryDetails } from 'app/model/enquiry-details';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EnqcommonService {

//for Enquiry backend connectivity
get: string = "http://localhost:8085/getData";
save:string="http://localhost:8085/saveData";
update:string="http://localhost:8085/updateSaveData/";
single:string="http://localhost:8085/getCSingleData";
postcibil:string="http://localhost:8085/saveCibil";
getcibil:string="http://localhost:8085/getCibilScore";


constructor(private httpClient: HttpClient) { }


//--------------------For Enquiry------------------

saveEnq(enq: EnquiryDetails): Observable<EnquiryDetails> 
{
  console.log("eid--" + enq.eid);
  console.log("dob--" + enq.dob);
  console.log("name--" + enq.name);
  console.log("age--" + enq.age);

  return this.httpClient.post<EnquiryDetails>(this.save, enq);
}

getdata(): Observable<EnquiryDetails[]>
{
  return this.httpClient.get<EnquiryDetails[]>(this.get);
}
getSingle(eid:number):Observable<EnquiryDetails>
{
  //return this.httpClient.get<Employee>(this.url+"/"+id)//through db.json
  return this.httpClient.get<EnquiryDetails>(this.single+"/"+eid)
}
savecibildata(cibil:EnquiryDetails):Observable<EnquiryDetails>
{
  return this.httpClient.post<EnquiryDetails>(this.postcibil,cibil);
}
getcibildata(): Observable<any>
 {
 
  return this.httpClient.get<any>(this.getcibil);
}
updateCustomer(c:EnquiryDetails):Observable<EnquiryDetails>
{
  return this.httpClient.put<EnquiryDetails>(this.update+c.eid,c)
}

mailsender(e:EnquiryDetails):Observable<EnquiryDetails>
{
  return this.httpClient.post<EnquiryDetails>("http://localhost:8085/mail",e)
  // return this.httpClient.get<EnquiryDetails>("http://localhost:8085/mail/post",e)
}
}