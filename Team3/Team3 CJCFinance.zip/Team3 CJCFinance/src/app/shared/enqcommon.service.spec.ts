import { TestBed } from '@angular/core/testing';

import { EnqcommonService } from './enqcommon.service';

describe('EnqcommonService', () => {
  let service: EnqcommonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EnqcommonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
