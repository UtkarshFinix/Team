import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PersonalDocs } from 'app/model/personal-docs';
import { Registration } from 'app/model/registration';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PdocscommonService {

//for Doc uploading backend connectivity
get: string = "http://localhost:8085/AllDoc";
save:string="http://localhost:8085/savedoc";
update:string="http://locahost:8085/updateSaveData";

constructor(private httpClient: HttpClient) { }


//--------------------For Doc uploading------------------

saveDoc(uploadDocument: any): Observable<Document> 
{
  return this.httpClient.post<Document>(this.save, uploadDocument);
}

getdata(): Observable<Document[]>
 {
 
  return this.httpClient.get<Document[]>(this.get);
}


updateCustomer(uploadDocument:PersonalDocs): Observable<PersonalDocs> 
{
// /  return this.httpClient.patch<Document>(this.update, uploadDocument.customerid);

return this.httpClient.patch<PersonalDocs>(this.update,uploadDocument.status);

  // return this.httpClient.put<EnquiryDetails>(this.update+c.eid,c)
}
/////////////////////////////////////////////
getSingleCustomer(id:number):Observable<Registration>
{
  return this.httpClient.get<Registration>("http://localhost:8082/customer/get/"+id)
}
getDocSingle(documentid:number):Observable<any[]>
{
  return this.httpClient.get<any[]>("http://localhost:8082/documnet/getById/"+documentid);
}
getAllDocument():Observable<any[]>
{
 return this.httpClient.get<any[]>("http://localhost:8082/document/get");
}

}
