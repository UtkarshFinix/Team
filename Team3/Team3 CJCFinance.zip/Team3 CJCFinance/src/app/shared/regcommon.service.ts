import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Registration } from 'app/model/registration';
import { CustomerregisterComponent } from 'app/module/relationexecutive/customerregister/customerregister.component';
import { EnquiryComponent } from 'app/module/relationexecutive/enquiry/enquiry.component';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegcommonService {

 // url:string="http://localhost:8085";
getsingle="http://localhost:8085/getCSingleData";
//for Reg backend connectivity
get: string = "http://localhost:8085/getRegDetailsData";
save:string="http://localhost:8085/saveRegDetailsData";

//for Dinfo backend connectivity
getDI: string = "http://localhost:8085/getDIData";
saveDI:string="http://localhost:8085/saveDIData";

//for CAddress backend connectivity
getCA: string = "http://localhost:8085/getCAData";
saveCA:string="http://localhost:8085/saveCAData";

//for Ploan backend connectivity
getPL: string = "http://localhost:8085/getPreviousLoanData";
savePL:string="http://localhost:8085/savePreviousLoanData";

//for AccDetails backend connectivity
getAD: string = "http://localhost:8085/getAcctDetailsData";
saveAD:string="http://localhost:8085/saveAcctDetailsData";

//for PropInfo backend connectivity
getPinfo: string = "http://localhost:8085/getPropInfoData";
savePinfo:string="http://localhost:8085/savePropInfoData";

//for GDetails backend connectivity
getGdetails: string = "http://localhost:8085/getGuarentorData";
saveGdetails:string="http://localhost:8085/saveGuarentorData";

//for LoanDisburse backend connectivity
getLoanDis: string = "http://localhost:8085/getLoanDisbData";
saveLoanDis:string="http://localhost:8085/saveLoanDisbData";

//for Ledger backend connectivity
getLedger: string = "http://localhost:8085/getLedgerData";
saveLedger:string="http://localhost:8085/saveLedgerData";

//for Sanction backend connectivity
getSanction: string = "http://localhost:8085/getSanctionData";
saveSacntion:string="http://localhost:8085/saveSanctionData";

constructor(private httpClient: HttpClient) { }

getSingle(eid:number):Observable<Registration>
{
  //return this.httpClient.get<Employee>(this.url+"/"+id)//through db.json
  return this.httpClient.get<Registration>(this.getsingle+"/"+eid)
}


//--------------------For Reg------------------

saveReg(cr: Registration): Observable<Registration> 
{
 // return this.httpClient.post<CustomerregisterComponent>(this.url+"/saveRegDetailsData", cr);
 return this.httpClient.post<Registration>(this.save, cr);
}

getRegdata(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.get);
}

//--------------------For Dinfo------------------

saveDInfo(di: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.saveDI, di);
}

getDIdata(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getDI);
}

//--------------------For CAddress------------------

saveCAddress(ca: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.saveCA, ca);
}

getCAdata(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getCA);
}

//--------------------For Ploan------------------

savePloan(pl: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.savePL, pl);
}

getPloan(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getPL);
}

//--------------------For AccDeatils------------------

savead(ad: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.saveAD, ad);
}

getad(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getAD);
}

//--------------------For PropInfo------------------

savePI(pi: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.savePinfo, pi);
}

getPI(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getPinfo);
}

//--------------------For GDetails------------------

saveGdata(gd: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.saveGdetails, gd);
}

getGdata(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getGdetails);
}

//--------------------For LoanDisburse------------------

saveLD(ld: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.saveLoanDis, ld);
}

getLD(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getLoanDis);
}

//--------------------For Ledger------------------

saveLedgerdata(ledger: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.saveLedger, ledger);
}

getLedgerdata(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getLedger);
}

//--------------------For Sanction------------------

saveSanctiondata(sd: Registration): Observable<Registration> 
{
  

  return this.httpClient.post<Registration>(this.saveSacntion, sd);
}

getSanctiondata(): Observable<Registration[]>
 {
 
  return this.httpClient.get<Registration[]>(this.getSanction);
}

}