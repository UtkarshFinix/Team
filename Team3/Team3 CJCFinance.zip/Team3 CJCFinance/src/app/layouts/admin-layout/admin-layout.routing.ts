
import { Routes } from '@angular/router';

export const AdminLayoutRoutes: Routes = [

];
