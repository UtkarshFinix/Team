package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.viii_LoanDisbursement;


@Repository

public interface viii_LoanDisbursementHomeRepository extends JpaRepository<viii_LoanDisbursement, Integer> 
{
	
}
