package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.vi_PropInfo;

public interface vi_PropInfoHomeService {

	vi_PropInfo saveInsert(vi_PropInfo propinfo);

	List<vi_PropInfo> getallData();


	
	
	
	

}
