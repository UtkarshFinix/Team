package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.vii_GuarentorDetails;


@Repository

public interface vii_GuarentorDetailsHomeRepository extends JpaRepository<vii_GuarentorDetails, Integer> 
{
	
}
