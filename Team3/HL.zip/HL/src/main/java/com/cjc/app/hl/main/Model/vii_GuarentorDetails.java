package com.cjc.app.hl.main.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class vii_GuarentorDetails
{
	@GeneratedValue(strategy =  GenerationType.AUTO)
	@Id
	
	int gid;
	String gName; 
	String gDateofBirth;
	String gRelationshipwithCustomer;
	String gMobNo;
	String gAdharCardNo;
	String gJobDetails;
	String gloaclAddress;
	String gPermanentAddress;
	
	
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getgName() {
		return gName;
	}
	public void setgName(String gName) {
		this.gName = gName;
	}
	public String getgDateofBirth() {
		return gDateofBirth;
	}
	public void setgDateofBirth(String gDateofBirth) {
		this.gDateofBirth = gDateofBirth;
	}
	public String getgRelationshipwithCustomer() {
		return gRelationshipwithCustomer;
	}
	public void setgRelationshipwithCustomer(String gRelationshipwithCustomer) {
		this.gRelationshipwithCustomer = gRelationshipwithCustomer;
	}
	public String getgMobNo() {
		return gMobNo;
	}
	public void setgMobNo(String gMobNo) {
		this.gMobNo = gMobNo;
	}
	public String getgAdharCardNo() {
		return gAdharCardNo;
	}
	public void setgAdharCardNo(String gAdharCardNo) {
		this.gAdharCardNo = gAdharCardNo;
	}
	public String getgJobDetails() {
		return gJobDetails;
	}
	public void setgJobDetails(String gJobDetails) {
		this.gJobDetails = gJobDetails;
	}
	public String getGloaclAddress() {
		return gloaclAddress;
	}
	public void setGloaclAddress(String gloaclAddress) {
		this.gloaclAddress = gloaclAddress;
	}
	public String getgPermanentAddress() {
		return gPermanentAddress;
	}
	public void setgPermanentAddress(String gPermanentAddress) {
		this.gPermanentAddress = gPermanentAddress;
	}


	
}
