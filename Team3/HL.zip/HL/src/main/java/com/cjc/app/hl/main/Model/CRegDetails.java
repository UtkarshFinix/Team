package com.cjc.app.hl.main.Model;



import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToOne;

@Entity
public class CRegDetails
{
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	@Id
	
	int eid;
	String Name;
	String DOB;
	int Age;
	String Gender;
	String Email;
	String MobileNo;
	String cAdditionalMobileNo;
	String cTotalLoanRequired; 
	String Totalamount;
	String PayableDownpaymnt;
	int Tenure;
	double cibilscore;

public int getEid() {
		return eid;
	}


	public void setEid(int eid) {
		this.eid = eid;
	}


	//	@OneToOne(cascade = CascadeType.ALL)
//	i_AllPersonalDocs docs;
//	
//	
	@OneToOne(cascade = CascadeType.ALL)
	ii_DependentInfo dinfo;
	
	@OneToOne(cascade = CascadeType.ALL)
	iii_CustomerAddress caddrs;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	iv_PreviousLoan ploan;
	
	@OneToOne(cascade = CascadeType.ALL)
	v_AccountDetails adetails;
	
	@OneToOne(cascade = CascadeType.ALL)
	vi_PropInfo pinfo;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	vii_GuarentorDetails gdetails;




	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getDOB() {
		return DOB;
	}


	public void setDOB(String dOB) {
		DOB = dOB;
	}


	public int getAge() {
		return Age;
	}


	public void setAge(int age) {
		Age = age;
	}


	public String getGender() {
		return Gender;
	}


	public void setGender(String gender) {
		Gender = gender;
	}


	public String getEmail() {
		return Email;
	}


	public void setEmail(String email) {
		Email = email;
	}


	public String getMobileNo() {
		return MobileNo;
	}


	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}


	public String getcAdditionalMobileNo() {
		return cAdditionalMobileNo;
	}


	public void setcAdditionalMobileNo(String cAdditionalMobileNo) {
		this.cAdditionalMobileNo = cAdditionalMobileNo;
	}


	public String getcTotalLoanRequired() {
		return cTotalLoanRequired;
	}


	public void setcTotalLoanRequired(String cTotalLoanRequired) {
		this.cTotalLoanRequired = cTotalLoanRequired;
	}


	public String getTotalamount() {
		return Totalamount;
	}


	public void setTotalamount(String totalamount) {
		Totalamount = totalamount;
	}


	public String getPayableDownpaymnt() {
		return PayableDownpaymnt;
	}


	public void setPayableDownpaymnt(String payableDownpaymnt) {
		PayableDownpaymnt = payableDownpaymnt;
	}


	public int getTenure() {
		return Tenure;
	}


	public void setTenure(int tenure) {
		Tenure = tenure;
	}


	public double getCibilscore() {
		return cibilscore;
	}


	public void setCibilscore(double cibilscore) {
		this.cibilscore = cibilscore;
	}


	public ii_DependentInfo getDinfo() {
		return dinfo;
	}


	public void setDinfo(ii_DependentInfo dinfo) {
		this.dinfo = dinfo;
	}


	public iii_CustomerAddress getCaddrs() {
		return caddrs;
	}


	public void setCaddrs(iii_CustomerAddress caddrs) {
		this.caddrs = caddrs;
	}


	public iv_PreviousLoan getPloan() {
		return ploan;
	}


	public void setPloan(iv_PreviousLoan ploan) {
		this.ploan = ploan;
	}


	public v_AccountDetails getAdetails() {
		return adetails;
	}


	public void setAdetails(v_AccountDetails adetails) {
		this.adetails = adetails;
	}


	public vi_PropInfo getPinfo() {
		return pinfo;
	}


	public void setPinfo(vi_PropInfo pinfo) {
		this.pinfo = pinfo;
	}


	public vii_GuarentorDetails getGdetails() {
		return gdetails;
	}


	public void setGdetails(vii_GuarentorDetails gdetails) {
		this.gdetails = gdetails;
	}
	
	

	
}
