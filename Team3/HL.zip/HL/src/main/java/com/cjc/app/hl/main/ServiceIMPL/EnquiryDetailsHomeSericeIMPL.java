 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.EnquiryDetails;
import com.cjc.app.hl.main.Repository.EnquiryDetailsHomeRepository;
import com.cjc.app.hl.main.Service.EnquiryDetailsHomeService;


@Service
public class EnquiryDetailsHomeSericeIMPL implements EnquiryDetailsHomeService
{
	@Autowired
	public EnquiryDetailsHomeRepository har;

	@Override
	public EnquiryDetails saveEnqInsert(EnquiryDetails enq) 
	{
		
		return har.save(enq);
	}

	@Override
	public List<EnquiryDetails> getallEnqData() 
	{
		List<EnquiryDetails>a=har.findAll();
		return a;
	}

	@Override
	public int savecibil(int cibil) 
	{
		
		return har.save(cibil);
	}

	@Override
	public Optional<EnquiryDetails> singleEData(int eid) 
	{
		return har.findById(eid);
	}

	@Override
	public EnquiryDetails insertData(EnquiryDetails e) {
		return har.save(e);
	}

	@Override
	public EnquiryDetails getSingel(int eid) {
		// TODO Auto-generated method stub
		return har.getById(eid);
	}
	


	

}
