 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.x_SanctionLetter;
import com.cjc.app.hl.main.Repository.x_SanctionLetterHomeRepository;
import com.cjc.app.hl.main.Service.x_SanctionLetterHomeService;


@Service
public class x_SanctionLetterHomeSericeIMPL implements x_SanctionLetterHomeService

{
	@Autowired
	public x_SanctionLetterHomeRepository slhr;

	@Override
	public x_SanctionLetter saveInsert(x_SanctionLetter ld) {
			return slhr.save(ld);
	}

	@Override
	public List<x_SanctionLetter> getallData() {
		List<x_SanctionLetter>a=slhr.findAll();
		return a;
	}




	

}
