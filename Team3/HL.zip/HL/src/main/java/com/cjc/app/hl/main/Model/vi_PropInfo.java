package com.cjc.app.hl.main.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class vi_PropInfo
{
	@GeneratedValue(strategy =  GenerationType.AUTO)
	@Id
	
	int propertyid;
	String propertytype;
	String propertyArea;
	String constructionArea;
	double propertyPrice;
	double constructionPrice;
	String property_Address;
	
	public String getProperty_Address() {
		return property_Address;
	}

	public void setProperty_Address(String property_Address) {
		this.property_Address = property_Address;
	}

	public int getPropertyid() {
		return propertyid;
	}

	public void setPropertyid(int propertyid) {
		this.propertyid = propertyid;
	}

	public String getPropertytype() {
		return propertytype;
	}

	public void setPropertytype(String propertytype) {
		this.propertytype = propertytype;
	}

	public String getPropertyArea() {
		return propertyArea;
	}

	public void setPropertyArea(String propertyArea) {
		this.propertyArea = propertyArea;
	}

	public String getConstructionArea() {
		return constructionArea;
	}

	public void setConstructionArea(String constructionArea) {
		this.constructionArea = constructionArea;
	}

	public double getPropertyPrice() {
		return propertyPrice;
	}

	public void setPropertyPrice(double propertyPrice) {
		this.propertyPrice = propertyPrice;
	}

	public double getConstructionPrice() {
		return constructionPrice;
	}

	public void setConstructionPrice(double constructionPrice) {
		this.constructionPrice = constructionPrice;
	}
	

}
