package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.iii_CustomerAddress;


@Repository

public interface iii_CustomerAddHomeRepository extends JpaRepository<iii_CustomerAddress, Integer> 
{
	
}
