package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.EnquiryDetails;


@Repository

public interface EnquiryDetailsHomeRepository extends JpaRepository<EnquiryDetails, Integer> 
{

	int save(int cibil);
	
}
