package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.ix_Ledger;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class ix_LedgerHomeController {
	@Autowired
	public ix_LedgerHomeService ldgrhs;


	@PostMapping("/saveLedgerData")
	public ix_Ledger saveLedgerData(@RequestBody ix_Ledger ldgr)
	{
		ix_Ledger ld= ldgrhs.saveInsert(ldgr);
		return ld;	
	}
	
	@GetMapping("/getLedgerData")
	public List<ix_Ledger >getLedgerData()
	{
		List<ix_Ledger >loandlist= ldgrhs.getallData();
		return loandlist;
	}

}
