 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.vii_GuarentorDetails;
import com.cjc.app.hl.main.Repository.vii_GuarentorDetailsHomeRepository;
import com.cjc.app.hl.main.Service.vii_GuarentorDetailsHomeService;


@Service
public class vii_GuarentorDetailsHomeSericeIMPL implements vii_GuarentorDetailsHomeService
{
	@Autowired
	public vii_GuarentorDetailsHomeRepository gdhr;

	@Override
	public vii_GuarentorDetails saveInsert(vii_GuarentorDetails gd) {
			return gdhr.save(gd);
	}

	@Override
	public List<vii_GuarentorDetails> getallData() {
		List<vii_GuarentorDetails>a=gdhr.findAll();
		return a;
	}




	

}
