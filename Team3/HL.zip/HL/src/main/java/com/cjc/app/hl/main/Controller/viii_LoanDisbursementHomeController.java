package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.viii_LoanDisbursement;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class viii_LoanDisbursementHomeController {
	@Autowired
	public viii_LoanDisbursementHomeService LDhs;


	@PostMapping("/saveLoanDisbData")
	public viii_LoanDisbursement saveLoanDisburData(@RequestBody viii_LoanDisbursement ldd)
	{
		viii_LoanDisbursement ld= LDhs.saveInsert(ldd);
		return ld;	
	}
	
	@GetMapping("/getLoanDisbData")
	public List<viii_LoanDisbursement >getLoanDisburData()
	{
		List<viii_LoanDisbursement >loandlist= LDhs.getallData();
		return loandlist;
	}

}
