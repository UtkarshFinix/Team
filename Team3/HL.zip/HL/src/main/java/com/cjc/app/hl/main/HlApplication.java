package com.cjc.app.hl.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
@SpringBootApplication
@EntityScan
public class HlApplication {

	public static void main(String[] args) {
		System.out.println("Home loan Project works....");
		SpringApplication.run(HlApplication.class, args);
		}

}
