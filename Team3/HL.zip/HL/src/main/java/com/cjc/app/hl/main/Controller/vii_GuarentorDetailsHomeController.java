package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.vii_GuarentorDetails;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class vii_GuarentorDetailsHomeController {
	@Autowired
	public vii_GuarentorDetailsHomeService gdhs;


	@PostMapping("/saveGuarentorData")
	public vii_GuarentorDetails saveguarentorData(@RequestBody vii_GuarentorDetails gd)
	{
		vii_GuarentorDetails ld= gdhs.saveInsert(gd);
		return ld;	
	}
	
	@GetMapping("/getGuarentorData")
	public List<vii_GuarentorDetails >getguarentorData()
	{
		List<vii_GuarentorDetails >loanlist= gdhs.getallData();
		return loanlist;
	}

}
