package com.cjc.app.hl.main.Service;


import java.util.List;
import com.cjc.app.hl.main.Model.CRegDetails;

public interface CRegDetailsHomeService {

	CRegDetails saveInsert(CRegDetails rd);

	List<CRegDetails> getallData();

//	Optional<CRegDetails> singlecData(int eid);


	
	

	
	
	
	

}
