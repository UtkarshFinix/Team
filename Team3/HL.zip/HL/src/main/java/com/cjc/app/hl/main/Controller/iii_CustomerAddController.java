package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.iii_CustomerAddress;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class iii_CustomerAddController {
	@Autowired
	public iii_CustomerAddHomeService chs;


	@PostMapping("/saveCAData")
	public iii_CustomerAddress saveCustAddData(@RequestBody iii_CustomerAddress ca)
	{
		iii_CustomerAddress custadd=chs.saveInsert(ca);
		return custadd;	
	}
	
	@GetMapping("/getCAData")
	public List<iii_CustomerAddress>getCustAddData()
	{
		List<iii_CustomerAddress>calist=chs.getallData();
		return calist;
	}
	

}
