 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.ix_Ledger;
import com.cjc.app.hl.main.Repository.ix_LedgerHomeRepository;
import com.cjc.app.hl.main.Service.ix_LedgerHomeService;


@Service
public class ix_LedgerHomeSericeIMPL implements ix_LedgerHomeService

{
	@Autowired
	public ix_LedgerHomeRepository ldhr;

	@Override
	public ix_Ledger saveInsert(ix_Ledger ldgr) {
			return ldhr.save(ldgr);
	}

	@Override
	public List<ix_Ledger> getallData() {
		List<ix_Ledger>a=ldhr.findAll();
		return a;
	}




	

}
