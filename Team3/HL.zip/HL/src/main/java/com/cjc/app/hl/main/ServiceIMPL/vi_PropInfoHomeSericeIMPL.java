 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.vi_PropInfo;
import com.cjc.app.hl.main.Repository.vi_PropInfoHomeRepository;
import com.cjc.app.hl.main.Service.vi_PropInfoHomeService;


@Service
public class vi_PropInfoHomeSericeIMPL implements vi_PropInfoHomeService
{
	@Autowired
	public vi_PropInfoHomeRepository pihr;

	@Override
	public vi_PropInfo saveInsert(vi_PropInfo pi) {
			return pihr.save(pi);
	}

	@Override
	public List<vi_PropInfo> getallData() {
		List<vi_PropInfo>a=pihr.findAll();
		return a;
	}




	

}
