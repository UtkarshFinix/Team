package com.cjc.app.hl.main.Model;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CIBIL_RandomNo 
{
	
//	
//	    public static void main(String args[])
//	    {
//	    	
//	    	private Logger logger = LoggerFactory.getLogger(this.getClass());
//	    	
//	    		private static final int SCORE_MAX = 800;
//	    		private static final int SCORE_MIN = 550;
//	    	
//	    		@RequestMapping(value = "/creditscore", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	    		@ResponseBody
//	    		public ResponseEntity<EnquiryDetails> creditScore(@RequestBody EnquiryDetails ED) 
//	    		
//	    		{
//	    			int score = Math.abs(ED.getName().hashCode() + ED.getDOB().hashCode()
//	    					+ ED.getMobileNo().hashCode() + ED.getPancardNo().hashCode());
//	    	
//	    			logger.info(ED.toString() + " hashcode: " + score);
//	    	
//	    			score = score % SCORE_MAX;
//	    	
//	    			while (score < SCORE_MIN)
//	    			{
//	    				score = score + 100;
//	    			}
//	    			
////	    			ED.setScore(score);
//	    	
//	    			ED.cibil.setCibilScore(score);
//	    			ResponseEntity<EnquiryDetails> response = new ResponseEntity<EnquiryDetails>(ED, HttpStatus.OK);
//	    	
//	    			return response;
//	    	
//	    		}
//	    
//	    }
}
	    


	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	  