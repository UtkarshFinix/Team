package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.i_AllPersonalDocs;

public interface i_AllPersonalDocsService 
{

	

	List<i_AllPersonalDocs> savedoc(i_AllPersonalDocs d);

	List<i_AllPersonalDocs> getDoc();

	List<i_AllPersonalDocs> getAlld();

	List<i_AllPersonalDocs> update(i_AllPersonalDocs ld);



	

}
