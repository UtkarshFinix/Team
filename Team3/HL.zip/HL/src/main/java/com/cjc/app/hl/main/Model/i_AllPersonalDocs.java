package com.cjc.app.hl.main.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity
public class i_AllPersonalDocs
{
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	public int did;
	public String status;
	private int customerid;
	
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	@Lob
	byte[] addressproof;
	@Lob
	byte[] pancard;
	@Lob
	byte[] itr;
	@Lob
	byte[] addharcard;
	@Lob
	byte[] photo;
	@Lob
	byte[] signature;
	
	public byte[] getAddressproof() {
		return addressproof;
	}
	public void setAddressproof(byte[] addressproof) {
		this.addressproof = addressproof;
	}
	public byte[] getPancard() {
		return pancard;
	}
	public void setPancard(byte[] pancard) {
		this.pancard = pancard;
	}
	public byte[] getItr() {
		return itr;
	}
	public void setItr(byte[] itr) {
		this.itr = itr;
	}
	public byte[] getAddharcard() {
		return addharcard;
	}
	public void setAddharcard(byte[] addharcard) {
		this.addharcard = addharcard;
	}
	public byte[] getPhoto() {
		return photo;
	}
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	public byte[] getSignature() {
		return signature;
	}
	public void setSignature(byte[] signature) {
		this.signature = signature;
	}

	

}
