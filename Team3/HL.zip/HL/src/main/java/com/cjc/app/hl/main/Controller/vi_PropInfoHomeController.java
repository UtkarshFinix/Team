package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.vi_PropInfo;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class vi_PropInfoHomeController {
	@Autowired
	public vi_PropInfoHomeService pihs;


	@PostMapping("/savePropInfoData")
	public vi_PropInfo savePropInfoData(@RequestBody vi_PropInfo propinfo)
	{
		vi_PropInfo ld= pihs.saveInsert(propinfo);
		return ld;	
	}
	
	@GetMapping("/getPropInfoData")
	public List<vi_PropInfo >getAcctDetailsData()
	{
		List<vi_PropInfo >loanlist= pihs.getallData();
		return loanlist;
	}

}
