package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.v_AccountDetails;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class v_AccountDetailsHomeController {
	@Autowired
	public v_AccountDetailsHomeService actdhs;


	@PostMapping("/saveAcctDetailsData")
	public v_AccountDetails saveAcctDetailsData(@RequestBody v_AccountDetails actd)
	{
		v_AccountDetails ld= actdhs.saveInsert(actd);
		return ld;	
	}
	
	@GetMapping("/getAcctDetailsData")
	public List<v_AccountDetails>getAcctDetailsData()
	{
		List<v_AccountDetails>loanlist= actdhs.getallData();
		return loanlist;
	}

}
