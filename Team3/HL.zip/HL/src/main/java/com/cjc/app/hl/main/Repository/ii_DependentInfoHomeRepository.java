package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.ii_DependentInfo;


@Repository

public interface ii_DependentInfoHomeRepository extends JpaRepository<ii_DependentInfo, Integer> 
{
	
}
