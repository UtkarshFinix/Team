package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.ix_Ledger;

public interface ix_LedgerHomeService {

	ix_Ledger saveInsert(ix_Ledger ldgr);

	List<ix_Ledger> getallData();

	

	
	

	
	
	
	

}
