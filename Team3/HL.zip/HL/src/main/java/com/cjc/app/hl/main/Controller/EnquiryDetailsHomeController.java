package com.cjc.app.hl.main.Controller;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.EnquiryDetails;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class EnquiryDetailsHomeController {
	@Autowired
	public EnquiryDetailsHomeService hs;
	@Autowired
	public JavaMailSender js;

		@PostMapping("/mail")
				public String send(@RequestBody EnquiryDetails cibil)
				{
					int eid=cibil.getEid();
					SimpleMailMessage smm=new SimpleMailMessage();
					EnquiryDetails enquriyOne=hs.getSingel(eid);
					smm.setTo(enquriyOne.getEmail());
					smm.setSubject("Cibil Status");
					if(cibil.getStatus().equals("Approved")) {
						smm.setText("Hello,Sir/Ma'am Your loan is approved, Your enquiry id is "+enquriyOne.getEid()+"Your cibil score is"+cibil.getCibil()+". Please visit bank for Registration.");
						js.send(smm);
						System.out.println(smm);
					}
					else {
						smm.setText("Hello,/n Your Loan request has been rejected due to less cibil score. Your cibil score is "+cibil.getCibil());
						js.send(smm);
						System.out.println(smm);
					}
					return "Send";
				}
	
	//For address
	@PostMapping("/saveData")
	public EnquiryDetails saveEnqData(@RequestBody EnquiryDetails enq)
	{
		EnquiryDetails eqd1=hs.saveEnqInsert(enq);
		return eqd1;	
	}
	
	@GetMapping("/getData")
	public List<EnquiryDetails>getEnqData()
	{
		List<EnquiryDetails>elist=hs.getallEnqData();
		return elist;
	}
	
	//ShowDetails Single Data OE
	@GetMapping("/getCSingleData/{eid}")
	public Optional<EnquiryDetails> singleEData(@PathVariable("eid") int eid)
	{
		Optional<EnquiryDetails> emp=hs.singleEData(eid);
		System.out.println(eid);
		return emp;
	}
	
	@PutMapping("/updateSaveData/{eid}")
	public EnquiryDetails editData(@RequestBody EnquiryDetails e, @PathVariable ("eid") int eid)
	{
		EnquiryDetails emp=hs.insertData(e);
		return emp;
	}
	
	
	//OE Update Cibil
	@PostMapping("/saveCibil")
	public int savecibilscore(@PathVariable ("cibil") int cibil )
	{
		int cibil1=hs.savecibil(cibil);
		return cibil1;
	}
	
	@GetMapping("/getCibilScore")  
	public int getCibilScorePage() 
	  {
		int min=600; 
		int max=900;
		System.out.println("Random value Cibil from  "+min+" to "+max+":");
		int random_int=(int)Math.floor(Math.random()*(max-min+1)+min);
		System.out.println("Cibil Score:- "+random_int);
	        return random_int;
	    }
	
	
	@PutMapping("/updateData/{eId}")
	public EnquiryDetails putData(@RequestBody EnquiryDetails addr, @PathVariable("eId") int eId)
	{
		EnquiryDetails a=hs.saveEnqInsert(addr);
		return a;
	}
}
