package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.ii_DependentInfo;

public interface ii_DependentInfoHomeService {

	ii_DependentInfo saveInsert(ii_DependentInfo depend);

	List<ii_DependentInfo> getallData();


	
	

}
