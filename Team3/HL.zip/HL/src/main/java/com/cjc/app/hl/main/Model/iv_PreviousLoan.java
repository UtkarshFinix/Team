package com.cjc.app.hl.main.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class iv_PreviousLoan
{
	@GeneratedValue(strategy =  GenerationType.AUTO)
	@Id
	
	int ploanId;
	double ploanAmount;
	int pTenure;
	double paidAmount;
	double remainingAmount;
	String previousbankIFSC;
	String status;
	String remark;
	public int getPloanId() {
		return ploanId;
	}
	public void setPloanId(int ploanId) {
		this.ploanId = ploanId;
	}
	public double getPloanAmount() {
		return ploanAmount;
	}
	public void setPloanAmount(double ploanAmount) {
		this.ploanAmount = ploanAmount;
	}
	public int getpTenure() {
		return pTenure;
	}
	public void setpTenure(int pTenure) {
		this.pTenure = pTenure;
	}
	public double getPaidAmount() {
		return paidAmount;
	}
	public void setPaidAmount(double paidAmount) {
		this.paidAmount = paidAmount;
	}
	public double getRemainingAmount() {
		return remainingAmount;
	}
	public void setRemainingAmount(double remainingAmount) {
		this.remainingAmount = remainingAmount;
	}
	public String getPreviousbankIFSC() {
		return previousbankIFSC;
	}
	public void setPreviousbankIFSC(String previousbankIFSC) {
		this.previousbankIFSC = previousbankIFSC;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}

}
