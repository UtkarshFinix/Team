package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.iv_PreviousLoan;

public interface iv_PreviousLoanHomeService {

	iv_PreviousLoan saveInsert(iv_PreviousLoan pvloan);

	List<iv_PreviousLoan> getallData();

	
	
	

}
