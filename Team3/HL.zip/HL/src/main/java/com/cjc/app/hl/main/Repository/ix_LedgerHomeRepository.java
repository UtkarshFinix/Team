package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.ix_Ledger;


@Repository

public interface ix_LedgerHomeRepository extends JpaRepository<ix_Ledger, Integer> 
{
	
}
