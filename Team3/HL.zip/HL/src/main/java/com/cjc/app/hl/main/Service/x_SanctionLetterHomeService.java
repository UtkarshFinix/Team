package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.x_SanctionLetter;

public interface x_SanctionLetterHomeService {

	x_SanctionLetter saveInsert(x_SanctionLetter sl);

	List<x_SanctionLetter> getallData();



	
	

	
	
	
	

}
