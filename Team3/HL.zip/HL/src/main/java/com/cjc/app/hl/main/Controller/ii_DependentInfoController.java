package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.ii_DependentInfo;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class ii_DependentInfoController {
	@Autowired
	public ii_DependentInfoHomeService dhs;


	@PostMapping("/saveDIData")
	public ii_DependentInfo saveDependData(@RequestBody ii_DependentInfo depend)
	{
		ii_DependentInfo di=dhs.saveInsert(depend);
		return di;	
	}
	
	@GetMapping("/getDIData")
	public List<ii_DependentInfo>getDependData()
	{
		List<ii_DependentInfo>dlist=dhs.getallData();
		return dlist;
	}
	

}
