package com.cjc.app.hl.main.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ii_DependentInfo
{
	@GeneratedValue(strategy =  GenerationType.AUTO)
	@Id
	
	int dId;
	String fatherName;
	String motherName;
	String noOfFamilyMember;
	String noOfChild;
	String maritalStatus;
	String dependentMember;
	String familyIncome;
	String spouseName;
	

	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getNoOfFamilyMember() {
		return noOfFamilyMember;
	}
	public void setNoOfFamilyMember(String noOfFamilyMember) {
		this.noOfFamilyMember = noOfFamilyMember;
	}
	public String getNoOfChild() {
		return noOfChild;
	}
	public void setNoOfChild(String noOfChild) {
		this.noOfChild = noOfChild;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getDependentMember() {
		return dependentMember;
	}
	public void setDependentMember(String dependentMember) {
		this.dependentMember = dependentMember;
	}
	public String getFamilyIncome() {
		return familyIncome;
	}
	public void setFamilyIncome(String familyIncome) {
		this.familyIncome = familyIncome;
	}
	public String getSpouseName() {
		return spouseName;
	}
	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}

	

}
