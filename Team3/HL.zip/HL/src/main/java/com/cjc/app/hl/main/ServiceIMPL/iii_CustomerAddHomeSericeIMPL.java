 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.iii_CustomerAddress;
import com.cjc.app.hl.main.Repository.iii_CustomerAddHomeRepository;
import com.cjc.app.hl.main.Service.iii_CustomerAddHomeService;


@Service
public class iii_CustomerAddHomeSericeIMPL implements iii_CustomerAddHomeService
{
	@Autowired
	public iii_CustomerAddHomeRepository cahr;

	@Override
	public iii_CustomerAddress saveInsert(iii_CustomerAddress ca) {
		return cahr.save(ca);
	}



	@Override
	public List<iii_CustomerAddress> getallData() 
	{
		List<iii_CustomerAddress>a=cahr.findAll();
		return a;
	}


	

}
