package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.iii_CustomerAddress;

public interface iii_CustomerAddHomeService {

	iii_CustomerAddress saveInsert(iii_CustomerAddress ca);

	List<iii_CustomerAddress> getallData();

	
	

}
