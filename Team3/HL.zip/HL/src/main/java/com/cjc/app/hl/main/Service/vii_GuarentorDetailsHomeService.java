package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.vii_GuarentorDetails;

public interface vii_GuarentorDetailsHomeService {

	vii_GuarentorDetails saveInsert(vii_GuarentorDetails gd);

	List<vii_GuarentorDetails> getallData();

	

	
	
	
	

}
