 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.iv_PreviousLoan;
import com.cjc.app.hl.main.Repository.iv_PreviousLoanHomeRepository;
import com.cjc.app.hl.main.Service.iv_PreviousLoanHomeService;


@Service
public class iv_PreviousLoanHomeSericeIMPL implements iv_PreviousLoanHomeService
{
	@Autowired
	public iv_PreviousLoanHomeRepository pvhr;

	@Override
	public iv_PreviousLoan saveInsert(iv_PreviousLoan pvloan) {
		// TODO Auto-generated method stub
		return pvhr.save(pvloan);
	}

	@Override
	public List<iv_PreviousLoan> getallData() {
		List<iv_PreviousLoan>a=pvhr.findAll();
		return a;
	}




	

}
