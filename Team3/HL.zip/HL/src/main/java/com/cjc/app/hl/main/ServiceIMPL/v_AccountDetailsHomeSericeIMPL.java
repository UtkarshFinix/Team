 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.v_AccountDetails;
import com.cjc.app.hl.main.Repository.v_AccountDetailsHomeRepository;
import com.cjc.app.hl.main.Service.v_AccountDetailsHomeService;


@Service
public class v_AccountDetailsHomeSericeIMPL implements v_AccountDetailsHomeService
{
	@Autowired
	public v_AccountDetailsHomeRepository acthr;

	@Override
	public v_AccountDetails saveInsert(v_AccountDetails actd) {
		// TODO Auto-generated method stub
		return acthr.save(actd);
	}

	@Override
	public List<v_AccountDetails> getallData() {
		List<v_AccountDetails>a=acthr.findAll();
		return a;
	}




	

}
