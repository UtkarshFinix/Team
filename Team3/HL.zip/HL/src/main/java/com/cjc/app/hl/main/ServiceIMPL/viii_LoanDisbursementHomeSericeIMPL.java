 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.viii_LoanDisbursement;
import com.cjc.app.hl.main.Repository.viii_LoanDisbursementHomeRepository;
import com.cjc.app.hl.main.Service.viii_LoanDisbursementHomeService;


@Service
public class viii_LoanDisbursementHomeSericeIMPL implements viii_LoanDisbursementHomeService

{
	@Autowired
	public viii_LoanDisbursementHomeRepository ldhr;

	@Override
	public viii_LoanDisbursement saveInsert(viii_LoanDisbursement ld) {
			return ldhr.save(ld);
	}

	@Override
	public List<viii_LoanDisbursement> getallData() {
		List<viii_LoanDisbursement>a=ldhr.findAll();
		return a;
	}




	

}
