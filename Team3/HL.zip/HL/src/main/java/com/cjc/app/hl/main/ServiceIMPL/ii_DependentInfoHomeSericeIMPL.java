 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.ii_DependentInfo;
import com.cjc.app.hl.main.Repository.ii_DependentInfoHomeRepository;
import com.cjc.app.hl.main.Service.ii_DependentInfoHomeService;


@Service
public class ii_DependentInfoHomeSericeIMPL implements ii_DependentInfoHomeService
{
	@Autowired
	public ii_DependentInfoHomeRepository dhr;

	@Override
	public ii_DependentInfo saveInsert(ii_DependentInfo depend) {
		return dhr.save(depend);
	}



	@Override
	public List<ii_DependentInfo> getallData() 
	{
		List<ii_DependentInfo>a=dhr.findAll();
		return a;
	}


	

}
