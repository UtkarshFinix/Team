package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.x_SanctionLetter;


@Repository

public interface x_SanctionLetterHomeRepository extends JpaRepository<x_SanctionLetter, Integer> 
{
	
}
