package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.iv_PreviousLoan;


@Repository

public interface iv_PreviousLoanHomeRepository extends JpaRepository<iv_PreviousLoan, Integer> 
{
	
}
