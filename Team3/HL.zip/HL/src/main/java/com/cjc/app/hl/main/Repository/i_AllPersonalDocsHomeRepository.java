package com.cjc.app.hl.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.app.hl.main.Model.i_AllPersonalDocs;


@Repository

public interface i_AllPersonalDocsHomeRepository extends JpaRepository<i_AllPersonalDocs, Integer> 
{

	i_AllPersonalDocs findByCustomerid(int customerid);

//	i_AllPersonalDocs findByDid(int did);
	
}
