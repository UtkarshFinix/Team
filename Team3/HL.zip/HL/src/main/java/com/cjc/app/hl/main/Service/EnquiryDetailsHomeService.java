package com.cjc.app.hl.main.Service;


import java.util.List;
import java.util.Optional;

import com.cjc.app.hl.main.Model.EnquiryDetails;

public interface EnquiryDetailsHomeService {


	
	public EnquiryDetails saveEnqInsert(EnquiryDetails enq);

	public List<EnquiryDetails> getallEnqData();

	public int savecibil(int cibil);

	public Optional<EnquiryDetails> singleEData(int eid);

	public EnquiryDetails insertData(EnquiryDetails e);

	public EnquiryDetails getSingel(int eid);

	



	

	

}
