package com.cjc.app.hl.main.Controller;



import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cjc.app.hl.main.Model.i_AllPersonalDocs;
import com.cjc.app.hl.main.Service.*;
import com.google.gson.Gson;


@CrossOrigin("*")
@RestController
public class i_AllPersonalDocsController 
{
	@Autowired
	public i_AllPersonalDocsService aphs;


	@RequestMapping(value = "/savedoc",method = RequestMethod.POST,consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public List<i_AllPersonalDocs> m1(@RequestPart(required = true, value = "addressproof") MultipartFile files1,
			@RequestPart(required = true, value = "pancard") MultipartFile files2,
			@RequestPart(required = true, value = "itr") MultipartFile files3,
			@RequestPart(required = true, value = "addharcard") MultipartFile files4,
			@RequestPart(required = true, value = "photo") MultipartFile files5,
			@RequestPart(required = true, value = "signature") MultipartFile files6,
			@RequestPart("doc") String doc
			) throws IOException{		
		System.out.println("inside method");
		
		i_AllPersonalDocs d=new i_AllPersonalDocs();
		d.setAddressproof(files1.getBytes());
		d.setPancard(files2.getBytes());
		d.setItr(files3.getBytes());
		d.setAddharcard(files4.getBytes());
		d.setPhoto(files5.getBytes());
		d.setSignature(files6.getBytes());		
		
		Gson gson=new Gson();
		i_AllPersonalDocs d1=gson.fromJson(doc,i_AllPersonalDocs.class);
		d.setStatus(d1.getStatus());
		List<i_AllPersonalDocs> list=aphs.savedoc(d);
		return list;
	}
	@GetMapping("/files")
	public List<i_AllPersonalDocs> getFiles()
	{
		return aphs.getDoc();
	}

	@GetMapping("/AllDoc")
	public List<i_AllPersonalDocs> getAlldoc()
	{
		return aphs.getAlld();
	}
	@RequestMapping(value = "/updateSaveData",method = RequestMethod.PATCH)
	public List<i_AllPersonalDocs> update
	(
			@RequestPart("doc")String doc)throws IOException
	{
	System.out.println(doc);	
		i_AllPersonalDocs ld=new i_AllPersonalDocs();
		Gson gson=new Gson();
		i_AllPersonalDocs d1=gson.fromJson(doc,i_AllPersonalDocs.class);
//		ld.setCustomerid(d1.getCustomerid());
		ld.setStatus(d1.getStatus());
	System.out.println(ld);
	
		List<i_AllPersonalDocs>list=aphs.update(ld);
		return list;		
}	
}
