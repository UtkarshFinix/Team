 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.i_AllPersonalDocs;
import com.cjc.app.hl.main.Repository.i_AllPersonalDocsHomeRepository;
import com.cjc.app.hl.main.Service.i_AllPersonalDocsService;


@Service
public class i_AllPersonalDocsServiceImpl implements i_AllPersonalDocsService
{
	@Autowired
	public i_AllPersonalDocsHomeRepository aphr;

	@Override
	public List<i_AllPersonalDocs> savedoc(i_AllPersonalDocs d) 
	{
		System.out.println("service data:-"+d);
		aphr.save(d);
		List<i_AllPersonalDocs> l1=aphr.findAll();
		return l1;
	}

	@Override
	public List<i_AllPersonalDocs> getDoc() 
	{
		List<i_AllPersonalDocs> l1=aphr.findAll();
		return l1;
	}

	@Override
	public List<i_AllPersonalDocs> getAlld() {
		List<i_AllPersonalDocs> doc=aphr.findAll();
		return doc;
	}

	@Override
	public List<i_AllPersonalDocs> update(i_AllPersonalDocs ld) {
		i_AllPersonalDocs id=aphr.findByCustomerid(ld.getCustomerid());
//		i_AllPersonalDocs id=aphr.findByDid(ld.getDid());
		id.setStatus(ld.getStatus());
		aphr.save(id);
		List<i_AllPersonalDocs>update=aphr.findAll();
		return update;
	}
}
