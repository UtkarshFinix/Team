package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.v_AccountDetails;

public interface v_AccountDetailsHomeService {

	List<v_AccountDetails> getallData();

	v_AccountDetails saveInsert(v_AccountDetails actd);

	
	
	
	

}
