 package com.cjc.app.hl.main.ServiceIMPL;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.Model.CRegDetails;
import com.cjc.app.hl.main.Repository.CRegDetailsHomeRepository;
import com.cjc.app.hl.main.Service.CRegDetailsHomeService;


@Service
public class CRegDetailsHomeSericeIMPL implements CRegDetailsHomeService
{
	@Autowired
	public CRegDetailsHomeRepository gdhr;

	@Override
	public CRegDetails saveInsert(CRegDetails gd) {
			return gdhr.save(gd);
	}

	@Override
	public List<CRegDetails> getallData() {
		List<CRegDetails>a=gdhr.findAll();
		return a;
	}
//
//	@Override
//	public Optional<CRegDetails> singlecData(int eid) {
//		return gdhr.findById(eid);
//	}




	

}
