package com.cjc.app.hl.main.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.CRegDetails;
import com.cjc.app.hl.main.Model.EnquiryDetails;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class CRegDetailsHomeController {
	@Autowired
	public CRegDetailsHomeService rdhr;


	@PostMapping("/saveRegDetailsData")
	public CRegDetails saveRegData(@RequestBody CRegDetails rd)
	{
		CRegDetails crd= rdhr.saveInsert(rd);
		return crd;	
	}
	
	@GetMapping("/getRegDetailsData")
	public List<CRegDetails >getRegData()
	{
		List<CRegDetails >getdata= rdhr.getallData();
		return getdata;
	}
	
//	@PostMapping("/sanction")
//	public String send(@RequestBody CRegDetails eid)
//	{
//		int si=eid.getEid();
//		
//		CRegDetails sl=rdhr.getsl(eid);
//		
//		SimpleMailMessage smm=new SimpleMailMessage();
////		smm.setTo(enquriyOne.getEmail());
//
////		smm.setTo("sumit.devarshi3@gmail.com");
//		smm.setTo("atulpawar34@gmail.com");
////		smm.setCc("gitte.nilesh3@gmail.com");
////		smm.setCc("kaveriingalwad810@gmail.com");
////		smm.setCc("snehaldeshmukh168@gmail.com")
//		
//		smm.setSubject("Cibil Status");
////		if(cibil.getStatus().equals("accepted")) {
////			smm.setText("Hello,/n Your loan is approved, Your enquiry id is "+enquriyOne.getEID()+". Please visit bank for Registration.");
////			javamailsender.send(smm);
////			System.out.println(smm);
////		}
////		else {
////			smm.setText("Hello,/n Your Loan request has been rejected due to less cibil score. Your cibil score is "+cibil.getCibilScore());
////			javamailsender.send(smm);
////			System.out.println(smm);
////		}
//		smm.setText("hello atul");
//		js.send(smm);
//		System.out.println(smm);
//		return "Send";
	}
