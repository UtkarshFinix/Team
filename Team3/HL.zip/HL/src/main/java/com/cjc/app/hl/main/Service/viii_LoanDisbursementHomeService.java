package com.cjc.app.hl.main.Service;


import java.util.List;

import com.cjc.app.hl.main.Model.viii_LoanDisbursement;

public interface viii_LoanDisbursementHomeService {

	viii_LoanDisbursement saveInsert(viii_LoanDisbursement gd);

	List<viii_LoanDisbursement> getallData();

	
	

	
	
	
	

}
