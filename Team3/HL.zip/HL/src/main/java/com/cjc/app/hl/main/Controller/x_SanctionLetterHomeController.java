package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.x_SanctionLetter;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class x_SanctionLetterHomeController {
	@Autowired
	public x_SanctionLetterHomeService slhs;


	@PostMapping("/saveSanctionData")
	public x_SanctionLetter saveSanctionltrData(@RequestBody x_SanctionLetter sl)
	{
		x_SanctionLetter ld= slhs.saveInsert(sl);
		return ld;	
	}
	
	@GetMapping("/getSanctionData")
	public List<x_SanctionLetter >getSanctionltrData()
	{
		List<x_SanctionLetter >loandlist= slhs.getallData();
		return loandlist;
	}

}
