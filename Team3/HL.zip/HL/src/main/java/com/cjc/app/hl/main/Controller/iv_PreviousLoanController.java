package com.cjc.app.hl.main.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.hl.main.Model.iv_PreviousLoan;
import com.cjc.app.hl.main.Service.*;

@CrossOrigin("*")
@RestController
public class iv_PreviousLoanController {
	@Autowired
	public iv_PreviousLoanHomeService pvhs;


	@PostMapping("/savePreviousLoanData")
	public iv_PreviousLoan savePreviousData(@RequestBody iv_PreviousLoan pvloan)
	{
		iv_PreviousLoan ld= pvhs.saveInsert(pvloan);
		return ld;	
	}
	
	@GetMapping("/getPreviousLoanData")
	public List<iv_PreviousLoan>getPreviousData()
	{
		List<iv_PreviousLoan>loanlist= pvhs.getallData();
		return loanlist;
	}

}
